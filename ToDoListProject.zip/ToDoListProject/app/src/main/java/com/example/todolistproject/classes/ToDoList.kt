package com.example.todolistproject.classes

class ToDoList(val name: String){}