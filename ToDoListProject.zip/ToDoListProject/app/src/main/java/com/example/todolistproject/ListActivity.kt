package com.example.todolistproject
// Este es el manejo de la vista personaliza de cada lista, contiene un recyclerview para los items y botones que aun
// no son necesarios y que muestran un Toast.
// Su función para esta entrega es poder mostrar los items de cada lista y que al volver no se haya perdido el orden de las listas.
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.todolistproject.adapters.CompleteItemsAdapter
import com.example.todolistproject.adapters.UncompleteItemsAdapter
import com.example.todolistproject.classes.Item
import kotlinx.android.synthetic.main.activity_list.*

class ListActivity : AppCompatActivity() {

    companion object {
        var LIST = "LIST"
    }

    private lateinit var linearLayoutManager2: LinearLayoutManager
    private lateinit var adapter2 : UncompleteItemsAdapter
    private lateinit var linearLayoutManager3: LinearLayoutManager
    private lateinit var adapter3 : CompleteItemsAdapter
    var itemsCreatedCounter = 1 //Cantidad de Items
    var current_list: List?= null//Lista que se esta mostrando

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        var list: List = intent.getParcelableExtra(LIST)!!
        textViewListName.text = list.name
        current_list = list
        linearLayoutManager2 = LinearLayoutManager(this)
        recyclerViewUncompleted.layoutManager = linearLayoutManager2
        adapter2 = UncompleteItemsAdapter(current_list!!.list_items as ArrayList<Item>)
        recyclerViewUncompleted.adapter = adapter2

        /*
        linearLayoutManager3 = LinearLayoutManager(this)
        recyclerViewCompleted.layoutManager = linearLayoutManager3
        adapter3 = CompleteItemsAdapter(listItemsCompleted as ArrayList<Item>)
        recyclerViewCompleted.adapter = adapter3

         */
        //Se devulve a la vista anterior
        buttonBack.setOnClickListener(){
           onBackPressed()
        }
    }

    //Se agrega un item a la lista
    fun onAddItemToListButtonClick(view: View){
        var newItem = Item("", "Item  $itemsCreatedCounter","No")
        itemsCreatedCounter++
        current_list?.list_items!!.add(newItem)
        adapter2.notifyItemInserted(current_list!!.list_items.size )
    }

    fun onCheckBoxItemClick(view: View){
        Toast.makeText(view.context,"No implementado aun", Toast.LENGTH_LONG).show()
        val checkBox : CheckBox = findViewById(view.id)
        checkBox.isChecked = false
    } // Tiene que completar el item o descompletar

    fun onShowCompleteButtonClick(view: View) { // Activa/desactiva visibilidad del 2do RecyclerView
        //if (recyclerViewCompleted.visibility==View.VISIBLE){recyclerViewCompleted.visibility=View.INVISIBLE}
        //else{ recyclerViewCompleted.visibility=View.VISIBLE}
        Toast.makeText(view.context,"No implementado aun",Toast.LENGTH_LONG).show()

    }

    fun onShareListButtonClick(view: View){
        Toast.makeText(view.context,"No implementado aun",Toast.LENGTH_LONG).show()
    } // Tiene que compartir lista

    //Devuelve la lista actualizada con todos los items dentro, se vuelve a la vista anterio
    override fun onBackPressed() {
        val data = Intent().apply {
            putExtra(LIST,current_list)
        }
        setResult(Activity.RESULT_OK,data)
        finish()
        super.onBackPressed()
    }
}
