package com.example.todolistproject.utils

const val BASE_URL = "https://6bc67247-ecef-494d-990f-65b783067900.mock.pstmn.io/"
